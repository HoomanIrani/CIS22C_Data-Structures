Hello Dr. Eftekhari,

This program compiles and works fine on Visual Studio, Xcode and g++.
You can run it on a UNIX machine that has g++ with the following script

       	$ g++ main.cpp DisjointSets.cpp DisjointSets.h Graph.cpp Graph.h Room.cpp Room.h                                                                                                                  Graph.h Room.cpp Room.h
	$ a.out
	$ a.out maze.txt



I've compiled it on multiple systems without error. 


	
Best Wishes,
Houman Irani & Mahbod Mohebi